


long double ** A = NULL;
long double ** AComplement = NULL;
long double ** B = NULL; 
long double ** BComplement = NULL;
long double * Pi = NULL; 
long double * PiComplement = NULL;

long double *** xi = NULL;
long double ** alpha = NULL;
long double ** codebook = NULL;
long double pOfOGivenLambda = 0;
long double pStar = 0,pStarComplement = 0,floorB = 1e-30;
long double ** beta = NULL; 
long double ** delta = NULL; 
long double ** gamma = NULL; 


int ** psi = NULL;
int * O = NULL;
FILE * AComplementFile = NULL;
int * qStar = NULL;
int * qStarComplement = NULL;
char * resultWord = NULL;
int N = 0; 
int M = 0; 
FILE * BComplementFile = NULL;
int T = 100;
int R = 0;
int duration = 0;
int p = 12;
int universeSize = 0;
FILE * PiComplementFile = NULL;

void define(){
	int i = 0;
	int j = 0;
	delta = new long double *[N];
	psi =new int *[N];
	qStar= new int[T];
	qStarComplement=new int[T];

	for (i =0;i<N; i=i+1){
		delta[i] = new long double[T];	
	}
	i=0;
	for(;i<N;i=i+1){
		psi[i] = new int[T];
	}

	xi = new long double ** [N];
	i = 0;
	for(; i <N;i=i+1){
		xi[i] = new long double * [N];	
	}
	for (i=0;i<N;i=i+1){
		for (j = 0;j<N; j=j+1){
			xi[i][j] = new long double[T-1];
		}
	}
	
	gamma = new long double * [N];
	i = 0;
	for (;i<N;i=i+1){
		gamma[i] = new long double[T];	
	}

	PiComplement = new long double [N];
	AComplement = new long double * [N];

	for (i=0;i<N;i=i+1){
		AComplement[i] = new long double[N];	
	}
	BComplement = new long double * [N];
	for (i=0;i<N;i=i+1){
		BComplement[i] = new long double[M];
	}
	O = new int [N]; //Observation Sequence
}	