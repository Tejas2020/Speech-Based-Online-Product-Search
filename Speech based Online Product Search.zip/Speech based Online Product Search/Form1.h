#pragma once
// #include "LiveTrain.h"
#include <msclr\marshal_cppstd.h>
#include "FinalProject.h"

namespace SpeechbasedOnlineProductSearch {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
		}

	protected:
	
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}


	private: System::Windows::Forms::Button^  liveTrainBtn;
	private: System::Windows::Forms::Button^  liveTestBtn;



	private: System::Windows::Forms::TextBox^  searchTextBox;
	private: System::Windows::Forms::Button^  searchBtn;
	private: System::Windows::Forms::Label^  searchLabel;
	private: System::Windows::Forms::Button^  recordBtn;
	private: System::Windows::Forms::Button^  doneBtn;
	private: System::Windows::Forms::PictureBox^  cartIcon;

	private: System::Windows::Forms::Label^  recordLabel;
	private: System::Windows::Forms::TextBox^  Description;
	private: System::Windows::Forms::Label^  doneLabel;
	private: System::Windows::Forms::Label^  searchBarLabel;

	private: System::Windows::Forms::Label^  recordBtnLabel;
	protected:  
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->liveTrainBtn = (gcnew System::Windows::Forms::Button());
			this->liveTestBtn = (gcnew System::Windows::Forms::Button());
			this->searchTextBox = (gcnew System::Windows::Forms::TextBox());
			this->searchBtn = (gcnew System::Windows::Forms::Button());
			this->searchLabel = (gcnew System::Windows::Forms::Label());
			this->recordBtn = (gcnew System::Windows::Forms::Button());
			this->doneBtn = (gcnew System::Windows::Forms::Button());
			this->cartIcon = (gcnew System::Windows::Forms::PictureBox());
			this->recordLabel = (gcnew System::Windows::Forms::Label());
			this->Description = (gcnew System::Windows::Forms::TextBox());
			this->doneLabel = (gcnew System::Windows::Forms::Label());
			this->searchBarLabel = (gcnew System::Windows::Forms::Label());
			this->recordBtnLabel = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->cartIcon))->BeginInit();
			this->SuspendLayout();
			// 
			// liveTrainBtn
			// 
			this->liveTrainBtn->BackColor = System::Drawing::Color::OrangeRed;
			this->liveTrainBtn->Font = (gcnew System::Drawing::Font(L"Cambria", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->liveTrainBtn->ForeColor = System::Drawing::SystemColors::HighlightText;
			this->liveTrainBtn->Location = System::Drawing::Point(435, 312);
			this->liveTrainBtn->Name = L"liveTrainBtn";
			this->liveTrainBtn->Size = System::Drawing::Size(182, 56);
			this->liveTrainBtn->TabIndex = 2;
			this->liveTrainBtn->Text = L"Live Train";
			this->liveTrainBtn->UseVisualStyleBackColor = false;
			this->liveTrainBtn->Click += gcnew System::EventHandler(this, &Form1::liveTrainBtn_Click);
			// 
			// liveTestBtn
			// 
			this->liveTestBtn->BackColor = System::Drawing::Color::OrangeRed;
			this->liveTestBtn->Font = (gcnew System::Drawing::Font(L"Cambria", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->liveTestBtn->ForeColor = System::Drawing::SystemColors::HighlightText;
			this->liveTestBtn->Location = System::Drawing::Point(39, 312);
			this->liveTestBtn->Name = L"liveTestBtn";
			this->liveTestBtn->Size = System::Drawing::Size(182, 56);
			this->liveTestBtn->TabIndex = 3;
			this->liveTestBtn->Text = L"Live Test";
			this->liveTestBtn->UseVisualStyleBackColor = false;
			this->liveTestBtn->Click += gcnew System::EventHandler(this, &Form1::liveTestBtn_Click);
			// 
			// searchTextBox
			// 
			this->searchTextBox->BackColor = System::Drawing::Color::LightCyan;
			this->searchTextBox->Font = (gcnew System::Drawing::Font(L"Cambria", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->searchTextBox->HideSelection = false;
			this->searchTextBox->Location = System::Drawing::Point(39, 79);
			this->searchTextBox->Multiline = true;
			this->searchTextBox->Name = L"searchTextBox";
			this->searchTextBox->Size = System::Drawing::Size(425, 40);
			this->searchTextBox->TabIndex = 6;
			// 
			// searchBtn
			// 
			this->searchBtn->BackColor = System::Drawing::Color::Transparent;
			this->searchBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"searchBtn.BackgroundImage")));
			this->searchBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->searchBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->searchBtn->Font = (gcnew System::Drawing::Font(L"Cambria", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->searchBtn->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->searchBtn->Location = System::Drawing::Point(470, 79);
			this->searchBtn->Name = L"searchBtn";
			this->searchBtn->Size = System::Drawing::Size(104, 40);
			this->searchBtn->TabIndex = 7;
			this->searchBtn->UseVisualStyleBackColor = false;
			this->searchBtn->Click += gcnew System::EventHandler(this, &Form1::searchBtn_Click);
			// 
			// searchLabel
			// 
			this->searchLabel->AutoSize = true;
			this->searchLabel->Font = (gcnew System::Drawing::Font(L"Cambria", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->searchLabel->Location = System::Drawing::Point(35, 149);
			this->searchLabel->Name = L"searchLabel";
			this->searchLabel->Size = System::Drawing::Size(95, 20);
			this->searchLabel->TabIndex = 8;
			this->searchLabel->Text = L"search label";
			// 
			// recordBtn
			// 
			this->recordBtn->BackColor = System::Drawing::Color::Transparent;
			this->recordBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"recordBtn.BackgroundImage")));
			this->recordBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->recordBtn->Font = (gcnew System::Drawing::Font(L"Cambria", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->recordBtn->ForeColor = System::Drawing::SystemColors::HighlightText;
			this->recordBtn->Location = System::Drawing::Point(257, 298);
			this->recordBtn->Name = L"recordBtn";
			this->recordBtn->Size = System::Drawing::Size(140, 79);
			this->recordBtn->TabIndex = 9;
			this->recordBtn->UseVisualStyleBackColor = false;
			this->recordBtn->Click += gcnew System::EventHandler(this, &Form1::recordBtn_Click);
			// 
			// doneBtn
			// 
			this->doneBtn->BackColor = System::Drawing::Color::OrangeRed;
			this->doneBtn->Font = (gcnew System::Drawing::Font(L"Cambria", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->doneBtn->ForeColor = System::Drawing::SystemColors::HighlightText;
			this->doneBtn->Location = System::Drawing::Point(435, 453);
			this->doneBtn->Name = L"doneBtn";
			this->doneBtn->Size = System::Drawing::Size(182, 53);
			this->doneBtn->TabIndex = 10;
			this->doneBtn->Text = L"Done";
			this->doneBtn->UseVisualStyleBackColor = false;
			this->doneBtn->Click += gcnew System::EventHandler(this, &Form1::doneBtn_Click);
			// 
			// cartIcon
			// 
			this->cartIcon->BackColor = System::Drawing::Color::White;
			this->cartIcon->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"cartIcon.Image")));
			this->cartIcon->Location = System::Drawing::Point(137, 42);
			this->cartIcon->Name = L"cartIcon";
			this->cartIcon->Size = System::Drawing::Size(377, 250);
			this->cartIcon->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->cartIcon->TabIndex = 11;
			this->cartIcon->TabStop = false;
			// 
			// recordLabel
			// 
			this->recordLabel->AutoSize = true;
			this->recordLabel->Font = (gcnew System::Drawing::Font(L"Cambria", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->recordLabel->Location = System::Drawing::Point(35, 187);
			this->recordLabel->Name = L"recordLabel";
			this->recordLabel->Size = System::Drawing::Size(96, 20);
			this->recordLabel->TabIndex = 12;
			this->recordLabel->Text = L"record label";
			// 
			// Description
			// 
			this->Description->BackColor = System::Drawing::Color::White;
			this->Description->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->Description->Enabled = false;
			this->Description->Font = (gcnew System::Drawing::Font(L"MS PGothic", 19.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Description->ForeColor = System::Drawing::Color::OrangeRed;
			this->Description->Location = System::Drawing::Point(102, 416);
			this->Description->Multiline = true;
			this->Description->Name = L"Description";
			this->Description->Size = System::Drawing::Size(423, 90);
			this->Description->TabIndex = 13;
			this->Description->Text = L" Speech Based Online Product Search";
			this->Description->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->Description->TextChanged += gcnew System::EventHandler(this, &Form1::Description_TextChanged);
			// 
			// doneLabel
			// 
			this->doneLabel->AutoSize = true;
			this->doneLabel->Font = (gcnew System::Drawing::Font(L"Cambria", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->doneLabel->Location = System::Drawing::Point(349, 509);
			this->doneLabel->Name = L"doneLabel";
			this->doneLabel->Size = System::Drawing::Size(0, 16);
			this->doneLabel->TabIndex = 14;
			// 
			// searchBarLabel
			// 
			this->searchBarLabel->AutoSize = true;
			this->searchBarLabel->Font = (gcnew System::Drawing::Font(L"Cambria", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->searchBarLabel->Location = System::Drawing::Point(41, 53);
			this->searchBarLabel->Name = L"searchBarLabel";
			this->searchBarLabel->Size = System::Drawing::Size(285, 23);
			this->searchBarLabel->TabIndex = 15;
			this->searchBarLabel->Text = L"Type the word you want to train";
			// 
			// recordBtnLabel
			// 
			this->recordBtnLabel->AutoSize = true;
			this->recordBtnLabel->Font = (gcnew System::Drawing::Font(L"Cambria", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->recordBtnLabel->Location = System::Drawing::Point(284, 380);
			this->recordBtnLabel->Name = L"recordBtnLabel";
			this->recordBtnLabel->Size = System::Drawing::Size(71, 23);
			this->recordBtnLabel->TabIndex = 16;
			this->recordBtnLabel->Text = L"Record";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::Window;
			this->ClientSize = System::Drawing::Size(658, 573);
			this->Controls->Add(this->recordBtnLabel);
			this->Controls->Add(this->searchBarLabel);
			this->Controls->Add(this->searchTextBox);
			this->Controls->Add(this->doneLabel);
			this->Controls->Add(this->Description);
			this->Controls->Add(this->recordLabel);
			this->Controls->Add(this->recordBtn);
			this->Controls->Add(this->searchLabel);
			this->Controls->Add(this->cartIcon);
			this->Controls->Add(this->doneBtn);
			this->Controls->Add(this->searchBtn);
			this->Controls->Add(this->liveTestBtn);
			this->Controls->Add(this->liveTrainBtn);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->cartIcon))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
				searchBtn->Visible = false;
				searchBtn->Enabled = false;
				searchTextBox->Visible = false;
				searchTextBox->Enabled = false;
				searchLabel->Visible = false;
				searchLabel->Enabled = false;
				recordBtn->Visible = false;
				recordBtn->Enabled = false;
				doneBtn->Visible = false;
				doneBtn->Enabled = false;
				recordLabel->Visible = false;
				recordLabel->Enabled = false;
				doneLabel->Visible = false;
				doneLabel->Enabled = false;
				recordBtnLabel->Visible = false;
				searchBarLabel->Visible = false;
			 }

	private: System::Void liveTrainBtn_Click(System::Object^  sender, System::EventArgs^  e) {

				 liveTestBtn->Visible = false;
				 liveTestBtn->Enabled = false;
				 liveTrainBtn->Visible = false;
				 liveTrainBtn->Enabled = false;
				 searchBtn->Visible = true;
				searchBtn->Enabled = true ;
				searchTextBox->Visible = true;
				searchTextBox->Enabled = true;
				searchTextBox->Text = "";
				searchBarLabel->Visible = true;
				recordBtnLabel->Visible = false;
				doneBtn->Visible = true;
				doneBtn->Enabled = true;
				doneLabel->Visible = true;
				doneLabel->Enabled = true;
				cartIcon->Visible = false;
				Description->Visible = false;
			 }

	private: System::Void liveTestBtn_Click(System::Object^  sender, System::EventArgs^  e) {
	//		char *str1 = "start https://en.wikipedia.org/wiki/";
			char *str1 = "start https://www.flipkart.com/search?q=";
			char *str2 = performLiveTesting();
			//char *str3 = (char *)malloc(1 + strlen(str1)+ strlen(str2));
			char str3[1000];
		
			strcpy(str3, str1);
			strcat(str3, str2);
			printf("%s",str3);
			system(str3);
		}


	private: System::Void searchBtn_Click(System::Object^  sender, System::EventArgs^  e) {
				String^ strr = searchTextBox->Text;
				msclr::interop::marshal_context context;
				std::string str= context.marshal_as<std::string>(strr);
				int found = searchWord(str.c_str());
				if(found == 1) {
					searchLabel->Text = "Word already present in my Vocabulary!";
					recordLabel->Text = "Add another word to train";
				} else {
					searchLabel->Text = "This is a new word!";
					recordLabel->Text = "Press the record button and add ten utterance to update my vocabulary.";
				}
				searchLabel->Visible = true;
				searchLabel->Enabled = true;
				recordLabel->Visible = true;
				recordLabel->Enabled = true;
				recordBtn->Visible = true;
				recordBtn->Enabled = true;
				recordBtnLabel->Visible = true;
		 }

	private: System::Void recordBtn_Click(System::Object^  sender, System::EventArgs^  e) {
				recordWords();
				recordBtn->Enabled = false;
		 }

	private: System::Void doneBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			performLiveTraining();
			cartIcon->Visible = true;
			liveTestBtn->Visible = true;
			liveTestBtn->Enabled = true;
			liveTrainBtn->Visible = true;
			liveTrainBtn->Enabled = true;
			searchBtn->Visible = false;
			searchBtn->Enabled = false ;
			searchTextBox->Visible = false;
			searchTextBox->Enabled = false;
			searchLabel->Visible = false;
			searchLabel->Enabled = false;
			recordBtn->Visible = false;
			recordBtn->Enabled = false;
			doneBtn->Visible = false;
			doneBtn->Enabled = false;
			recordLabel->Visible = false;
			recordLabel->Enabled = false;
			doneLabel->Visible = false;
			doneLabel->Enabled = false;
			recordBtnLabel->Visible = false;
			searchBarLabel->Visible = false;
			Description->Visible = true;
		 }
private: System::Void resetBtn_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void Description_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

