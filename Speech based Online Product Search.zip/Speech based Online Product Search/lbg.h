extern int M, universeSize;
int K = M;
extern long double ** codebook;

void KMeans(char * fileName, int currK, long double delta, long double w[]){
	int minIndex = 9999999;
	
	long double previousDistortion = 0.0;
	long double currentDistortion = 1000.0;
	long double min = 1000000000.0, totalDistortion = 0.0;
	long double temp = 0;
	int m = 0; 
	long long int iterationCount = 0;
	int * bucketNumber = new int[universeSize], * bucketSize = new int[K]; //should lie between 0 to K-1 included
	long double * distances = new long double[K]; //stores the tokhura distances
	int j = 0;
	long double ** bucketSum = new long double*[K]; //stores the sum of buckets
	long double * currentUniverseVector = new long double[p]; // holds the current universe vector
	int i = 0,k = 0;
	FILE * file = NULL;
	for (i = 0; i < currK; i=i+1){
		bucketSum[i] = new long double[p];	
	}
	i = 0;
	for (; i < currK; i=i+1){
		bucketSize[i] = 0;	
	}
	for (i = 0; i < currK; i=i+1){
		j = 0;
		for (; j < p;j++){
			bucketSum[i][j] = 0;	
		}
	}
	i = 0;j = 0;
	while (abs(currentDistortion-previousDistortion) >= delta){
	totalDistortion = 0;
	iterationCount=iterationCount+1;
	i = 0;
	for (; i < currK; i=i+1){
		bucketSize[i] = 0;	
	}
	for (i = 0; i < currK; ++i)
		for (j = 0; j < p; ++j)
			bucketSum[i][j] = 0;
	file = fopen(fileName,"r");
	
	/*classification*/
	for (i = 0; i < universeSize;i=i+1){
		j = 0;
		for (; j < p; ++j){
			fscanf(file,"%lf",&temp); //read the next value
			currentUniverseVector[j] = temp; //add it to the corresponding index of the current universe vector
		}

		min = 100000000.0; //reset the minimum

		//find out the tokhura distances from each vector in the codebook
		for (j = 0; j < currK; j=j+1){
			distances[j] = 0;
			k = 0;
			for (; k < p;k=k+1){
				distances[j] += w[k]*(currentUniverseVector[k]-codebook[j][k])*(currentUniverseVector[k]-codebook[j][k]); //find out the distance
			}
		}

		//find out the minimum
		j = 0;
		for (; j < currK;j=j+1){
			if (min > distances[j]){
				min = distances[j];
				minIndex = j;
			}
		}

		//store the minIndex in the bucketNumber array
		bucketNumber[i] = minIndex;

		//increase the corresponding bucket size
		bucketSize[minIndex]=bucketSize[minIndex]+1;
	    j = 0;
		for (; j < p; j=j+1){
			bucketSum[minIndex][j] += currentUniverseVector[j];
		}
		totalDistortion += min;
	}

	/*code vector updation*/

	for (i = 0; i < currK; ++i){
		j = 0;
		for(; j < p; ++j){
			codebook[i][j] = bucketSum[i][j]/bucketSize[i];
		}
	}
	
	previousDistortion = currentDistortion; //store the previous distortion
	currentDistortion = totalDistortion / universeSize; //find out the current distortion
	fclose(file);
	}
	delete(bucketNumber);
	delete(bucketSize);
	delete(distances);
	delete(bucketSum);
	delete(currentUniverseVector);
}

void LBG(char * fileName, long double * initialCodebook, long double delta, long double epsilon, long double w[]){
	long double ** tempCodebook = NULL;
	int codebookSize = 1;
	codebook = NULL;
	codebook = new long double*[1];
	int i = 0;
	int j = 0, progressCount = 0, printGap = 0;
	int percentageSize = 0;

	
	for (i = 0; i < 1; ++i){
		codebook[i] = new long double[p];
	}

	//store the initial codebook in codebook
	for (i = 0; i < 1; ++i){
		for (j = 0; j < p; ++j){
			codebook[i][j] = initialCodebook[j];		
		}
	}
	
	//find out the progress printing details
	while(codebookSize != K)
	{
		codebookSize *= 2;
		
	}
	codebookSize = 1;
	
	printf("\n");
	while(codebookSize != K) //till the desired size is not reached
	{
		tempCodebook = new long double*[2*codebookSize]; //create a double sized codebook
		for (j = 0; j < 2*codebookSize; ++j)
			tempCodebook[j] = new long double[p];

		//split
		for (i = 0; i < codebookSize; ++i)
		{
			for (j = 0; j < p; ++j)
			{
				tempCodebook[2*i][j] = codebook[i][j]*(1+epsilon);
				tempCodebook[(2*i)+1][j] = codebook[i][j]*(1-epsilon);
			}
		}

		codebook = tempCodebook; //store the new codebook
		codebookSize *= 2; //update the new codebook size
		KMeans(fileName, codebookSize, delta, w); //run k means for optimal codebook	
	}
}

long double * getInitialCodebook(char * fileName, int rowSize){
	FILE * file = NULL;
	char * buffer = new char[rowSize];
	int i = 0, j = 0;
	long double temp = 0;
	long double * initialCodebook = new long double[p];

	j = 0;
	for (; j < p; j=j+1){
		initialCodebook[j] = 0;
	}

	//add all the vectors from the universe file
	file = fopen(fileName,"r");

	i = 0;
	for (; i < universeSize; i=i+1){
		j = 0;
		for (;j < p; j=j+1){
			fscanf(file,"%lf",&temp); //read the next value
			initialCodebook[j] += temp; //add it to the corresponding index of the initial codebook
		}
	}
	fclose(file);

	for (j = 0; j < p; j=j+1){
		initialCodebook[j] /= universeSize;
	}

	delete(buffer);
	return initialCodebook;
}

void buildCodebook(){
	/*variable declaration*/
	char * universeFileName = "data/universe.txt"; //universe file name
	
	int p = 12;
	int rowSize = 1024;
	K = M;
	long double epsilon = 0.03;
	long double delta = 0.00001; 
	long double w[] = {1.0,3.0,7.0,13.0,19.0,22.0,25.0,33.0,42.0,50.0,56.0,61.0}; 

	long double * initialCodebook = NULL;
	int i = 0, j = 0; //loop variables

	/*execution*/
	initialCodebook = getInitialCodebook(universeFileName, rowSize); //generate initial codebook	
	LBG(universeFileName, initialCodebook, delta, epsilon, w); //run LBG
	i = 0;
	FILE * codebookFile = fopen("data/codebook.txt","w+");
	for (; i < M; i=i+1){
		for (j = 0; j < p; j=j+1){
			fprintf(codebookFile,"%lf ",codebook[i][j]);		
		}
		fprintf(codebookFile,"\n");
	}
	fclose(codebookFile);	
}