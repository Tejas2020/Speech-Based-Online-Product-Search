extern long double ** A;
extern long double ** B;
extern long double ** alpha, ** beta;
extern int * O;
extern long double pOfOGivenLambda;
extern FILE * modelOutputFile;
extern int N;
extern int M, T;
extern long double * Pi;
extern FILE * dataOutputFile; 

void runForwardBackward(){
	int i = 0;
	int j = 0;
	int t = 0;

	//initialization
	for (i=0;i<N;i=i+1){
		alpha[i][0] = Pi[i]*B[i][O[0]-1];
	}
	//induction
	for(t=0; t<T-1;t=t+1){
		for(j=0;j<N;j=j+1){
			alpha[j][t+1] = 0;
			for (i = 0; i < N;i=i+1){
				alpha[j][t+1] =alpha[j][t+1] + alpha[i][t]*A[i][j];			
			}
			alpha[j][t+1] *= B[j][O[t+1]-1];
		}
	}
	//finding out probability
	pOfOGivenLambda = 0;
	for (i=0;i<N; i=i+1){
		pOfOGivenLambda =pOfOGivenLambda + alpha[i][T-1];
	}
	//initialization
	for(i = 0;i<N;i=i+1){
		beta[i][T-1] = 1;
	}

	//induction
	t=T-2;
	for(; t >= 0; t=t-1){
		for (i = 0; i<N; i=i+1){
			beta[i][t] = 0;
			for (j=0;j<N;j=j+1){
				beta[i][t] += A[i][j]*B[j][O[t+1]-1]*beta[j][t+1];		
			}
		}
	}
}