// FinalProject.cpp : Defines the entry point for the console application.
//
using namespace std;

#include "stdafx.h"
#include <iostream>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <direct.h>
#include <cstdio>
#include "variables.h"
#include "lbg.h"
#include "forwardbackward.h"
#include "viterbi.h"
#include "hmm.h"
#include "functions.h"
FILE * AFile = NULL, * BFile = NULL, * PiFile = NULL;
int D = 0;
int F = 0;
int ** fullO = NULL;
int trainFlag = 0;
char trainUserString[128];
extern long double *** xi,** alpha, ** beta, ** delta, ** gamma, ** codebook,* Pi, * PiComplement;
extern long double ** A, ** AComplement, ** B, ** BComplement;
extern int ** psi,* O, * qStar, * qStarComplement;
extern FILE * AComplementFile, * BComplementFile, * PiComplementFile;
extern char * resultWord;
extern int T, N, M, R, duration, p;

int preProcess();
int searchWord(const char *);
void trainBeginningModel(int);
void trainNewModel();

void initializeAlphaBeta(){
	int i=0;
	A = new long double *[N]; //A Matrix
	B = new long double *[N]; //B Matrix
	Pi = new long double[N]; //Pi Array

	for(i=0;i<N;i++){
		A[i] = new long double[N];
	}
	beta = new long double *[N];
	for(i=0;i<N;i++){
		B[i] = new long double[M];
	}
	alpha = new long double *[N];
	for(i=0;i<N;i++){
	  alpha[i] = new long double[T];
	}
	for(i=0;i<N;i++){
		beta[i] = new long double[T];
	}

	
}

//Live Training
void performLiveTraining() {
	FILE *file;
	file=NULL;
	int range = preProcess();
	char trainFileName[256];
	int currTrainCount = 0;
	if(trainFlag!=1) {
		trainNewModel();
	}else{
		sprintf(trainFileName,"HMM/%s/count.txt",trainUserString);
		file = fopen(trainFileName,"r");
		fscanf(file,"%d",&currTrainCount);
		sprintf(trainFileName,"HMM/%s/%d.txt",trainUserString,currTrainCount);
		trainModel(trainUserString,range,trainFileName);
		fclose(file);
	}
}



//record words
void recordWords() {
	FILE *file = NULL;
	char trainFileName[256];
	char filePath[128];
	
	char command[200];
	int currTrainCount = 0;
	int range = preProcess();
	file = fopen("data/D.txt","r");
	char ** digits = new char * [D];
	fscanf(file,"%d",&D);
	int d = 0;
	int i = 0;
	for (d=0;d<D;d++){
		digits[d]=(char*)malloc(sizeof(char *));
	}
	for (d=0;d<D;d++){
		fscanf(file,"%s",digits[d]);
	}
	//initialize
	initializeAlphaBeta();
	//new word
	if(trainFlag!=1){
		sprintf(filePath,"HMM/%s",trainUserString);
		mkdir(filePath);
		i= 0;
		while(i<R){
			sprintf(command,"Recording_Module.exe %d data/o.wav %s/%d.txt",duration,filePath,i);
			std :: system(command);
			++i;
		}
		// update the set of words in file as well as in the array
		file = fopen("data/D.txt","w");
		++D;
		fprintf(file,"%d\n",D);
		i = 0; 
		while (i < D-1){
			fprintf(file, "%s\n",digits[i]);
		     ++i;
		}
		fprintf(file,"%s\n",trainUserString);
		writeGeneralModel(filePath,R);
		fclose(file);
		//train the model from the beginning along with the live trained existing words
		range = preProcess();	
	}
	// existing word
	else{
		sprintf(trainFileName,"HMM/%s/count.txt",trainUserString);
		file = fopen(trainFileName,"r");
		fscanf(file,"%d",&currTrainCount);
		sprintf(trainFileName,"HMM/%s/%d.txt",trainUserString,currTrainCount);
		sprintf(command,"Recording_Module.exe %d data/o.wav %s",duration,trainFileName);
		fclose(file);
		std :: system(command);	
	}
}


//Live Testing
char* performLiveTesting() {
	char *testFileName="data/o.txt";
	int range;
	range=preProcess();
	char command[200];
	FILE *file = fopen("data/D.txt","r");
	char * folder = "HMM/";
	fscanf(file,"%d",&D);
	char ** digits = new char * [D];
	int i = 0;
	int j = 0;
	int d = 0;
	int r = 0;
	//initialize
	initializeAlphaBeta();
	d = 0; 
	while(d < D){
		digits[d] = (char *)malloc(sizeof(char *));	 
		++d;
	}
	d = 0;
	while( d < D){
	  fscanf(file,"%s",digits[d]);
	  ++d;
	}
	char ** files = NULL;
	char ** dataFiles = NULL;
	
	dataFiles = new char * [R];
	for (r=0; r < R; r++){
		dataFiles[r] = (char *)malloc(sizeof(char *));
	}	
	r = 0; 
	while(r < R){
		sprintf(dataFiles[r],"%d",r);
	    ++r;
	}
	fclose(file);
	files = new char * [4];
	r = 0;
	for( ;r < 3; ++r){
	  files[r] = (char *)malloc(sizeof(char *));
	}
		
	files[0] = "A";files[1] = "B";
	files[2] = "Pi";
	// recording module
	sprintf(command,"Recording_Module.exe %d data/o.wav data/o.txt",duration);
	std :: system(command);
	recognize(folder,digits, files, dataFiles, D,R, range, testFileName);
	return resultWord;
}

//Live Training
int searchWord(const char *input){
	FILE *file = NULL;
	file=fopen("data/D.txt","r");
	fscanf(file,"%d",&D);
	char ** digits = new char * [D];
	int d = 0;
	for(d=0;d <D;d++){
		digits[d] = (char *)malloc(sizeof(char *));		
	}
	int i = 0;
	for (d = 0; d < D; ++d){
		fscanf(file,"%s",digits[d]);	
	}
	trainFlag = 0;
	i = 0; 
	for(;i< D;i++){
		if (strcmp(input, digits[i]) == 0){
			trainFlag = 1;
			break;
		}
	}
	sprintf(trainUserString, "%s", input);
	fclose(file);	
	return trainFlag;
}



//getting range
int preProcess(){
	//read the duration
	FILE * file=NULL;
	file = fopen("data/duration.txt","r");
	int range = 0;
	duration=3;
	N=5;
	M=32;
	range=5000.0;
	file = fopen("data/F.txt","r");
	fscanf(file,"%d",&R);
	fclose(file);
	return range;
}

//beginning model
void trainBeginningModel(int buildingStatus){
	int i = 0;
	int j = 0;
	int k = 0;
	int r = 0;
	int c = 0, d = 0;
	int f = 0, t = 0;
	int m = 0, modelCount = 0;
	bool isUpdated = true;
	long double ** refA = NULL;
	long double * refPi = NULL;	
	long double value = 0;	
	long double ** refB = NULL; 
	FILE * file = NULL;
	int range = 0, progressCount = 0;
	int percentageSize = 50, modelLoop = 2, updationLimit = 0;
	char temp[100];

	//Read the updated information from info.txt
	R=10;
	F=R;
	//reading the existing words
	file = fopen("data/D.txt","r");
	fscanf(file,"%d",&D);
	fclose(file);

	char ** digits = new char * [D];
	char * folder = "HMM/";
	for(d=0;d <D;d++){
		digits[d] = (char *)malloc(sizeof(char *));		
	}
	i = 0;
	for (d = 0; d < D; ++d){
		fscanf(file,"%s",digits[d]);	
	}
	fclose(file);
	//resetting the D file for the first 15 words
	file = fopen("data/D.txt","w");
	fprintf(file,"%d\n",D);
	for(d=0;d<D;+d){
	 fprintf(file,"%s\n",digits[d]);
	}
		
	fclose(file);

	//updating the digits array with the old 15 words
	file = fopen("data/D.txt","r");
	fscanf(file,"%d",&D);
	digits = new char * [D];

	for(d=0;d<D;d++){
		digits[d] = (char *)malloc(sizeof(char *));
	}
	d = 0;
	while( d < D){
		fscanf(file,"%s",digits[d]);	 
		++d;
	}
	
	char ** files = NULL;
	fclose(file);
	char ** dataFiles = NULL;	
	file = fopen("data/duration.txt","r");
	fscanf(file,"%d",&duration);
	fclose(file);

	file = fopen("data/range.txt","r");
	fscanf(file,"%d",&range);
	fclose(file);

	N=5;
	M=32;
//	Building the universe and the codebook
	dataFiles = new char * [R];
	r = 0; 
	while(r < R){
		dataFiles[r] = (char *)malloc(sizeof(char *));	
	    ++r;
	}
	r = 0;
	for(;r<R;){
		sprintf(dataFiles[r],"%d",r);		
		++r;
	}
	files = new char * [4];
	r = 0;
	for(;r<4;){
		files[r] = (char *)malloc(sizeof(char *));	
		 ++r;
	}
	files[0] = "A";
	files[1] = "B";
	files[2] = "O";
	files[3] = "Pi";
	resetModel(folder, digits, dataFiles, D, R);
	resetCount(folder, digits, dataFiles, D, R);
	if (buildingStatus == 0){
		buildUniverse(folder, digits, dataFiles, D, R, range);
		// building codebook
		buildCodebook();
		printf("\nCodebook building completed\n");
	}
	
	//Define variables for HMM
	define();

	fullO = new int *[R];
	for (i = 0; i < R; ++i){
		fullO[i] = new int[T];	
	}

	refB = new long double *[N]; //B Matrix
	refA = new long double *[N]; //A Matrix
	refPi = new long double[N]; //Pi Array
	
	for(i= 0; i< N;i++){
		refB[i] = new long double[M];	
	}
	char * buffer = new char[1024];
	for(i=0;i<N;i++){
		refA[i] = new long double[N];	
	}
	char skipLine[1024];
	
	char fileName[100];
	char AComplementFileName[100], BComplementFileName[100];
	char PiComplementFileName[100];

//	Build the initial HMM
	while (modelCount != modelLoop) {
		modelCount=modelCount+1;
		//converge the model for each observation sequence
		d = 0; 
		while(d<D){
			generateObservationSequences(folder, digits, dataFiles, d, R, range); //generate the full observation sequence
			//read the model
			for (f=0; f<4;f++){
				sprintf(fileName,"%s%s/%s.txt",folder,digits[d],files[f]);
				file = fopen(fileName,"r");
				if (!f){
					i = 0; 
					while(i < N){
						j = 0;
						for(;j < N;j++){
							fscanf(file,"%lf",&A[i][j]);
							refA[i][j] = A[i][j];
						}
						++i;
					}
				}
				else if (f==1){
					for(i=0;i<N;i++){
						j=0;
						for (;j<M;j++){
							fscanf(file,"%lf",&B[i][j]);
							refB[i][j] = B[i][j];
						}
					}
				}
				else if (f==2){
					i = 0;
					while( i < R){
						for (j = 0; j < T; ++j){
							fscanf(file,"%d",&fullO[i][j]);						
						}
					    ++i;
					}				
				}
				else if(f==3){
					for(i=0;i < N;i=i+1){
						fscanf(file,"%lf",&Pi[i]);
						refPi[i] = Pi[i];				
					}
				}
				fclose(file);
			}

			for(k=0;k<R;k++){			
				sprintf(AComplementFileName,"%s%s/AComplement%d.txt",folder,digits[d],k);
				AComplementFile = fopen(AComplementFileName,"w+");
				sprintf(BComplementFileName,"%s%s/BComplement%d.txt",folder,digits[d],k);
				BComplementFile = fopen(BComplementFileName,"w+");
				sprintf(PiComplementFileName,"%s%s/PiComplement%d.txt",folder,digits[d],k);
				PiComplementFile = fopen(PiComplementFileName,"w+");
				
				for(i= 0; i <N;i++){
					for (j = 0;j<N;j++){
						A[i][j] = refA[i][j];		
					}
				}
				//reset B
				for(i=0;i<N;i++){
					for (m = 0; m < M; ++m){
						B[i][m] = refB[i][m];	
					}
				}
				//reset Pi
				for(j =0; j< N;j++){
					Pi[j]= refPi[j];	
				}

				O = fullO[k];
				isUpdated = true;
				//update new pStar
				runViterbi(0);
				updationLimit = 0;

				for(;isUpdated && updationLimit++ <= 200;){
					runForwardBackward();
					runBaumWelch();
					runViterbi(1);
					isUpdated = compareAndUpdateModel();
				}
			
				for(i=0;i<N;i++){
					for (j = 0; j < N; ++j){
						fprintf(AComplementFile,"%g ",A[i][j]);					
					}
					fprintf(AComplementFile,"\n");
				}
				fclose(AComplementFile);
				i = 0;
				for (;i< N;i++){
					m = 0;
					for (;m<M;m++){
						fprintf(BComplementFile,"%g ",B[i][m]);					
					}
					fprintf(BComplementFile,"\n");
				}
				fclose(BComplementFile);

			    j=0;
				for (;j<N;j++){
					fprintf(PiComplementFile,"%g ",Pi[j]);				
				}
				fprintf(PiComplementFile,"\n");
				fclose(PiComplementFile);
			}
			++d;
		}
		
		//replace the initial model with the new average model
		d = 0; 
		while(d< D){
			sprintf(fileName,"%s%s/A.txt",folder,digits[d]);
			AFile = fopen(fileName,"w");
			for (i = 0; i < N; ++i){
				for (j = 0; j < N; ++j){
					AComplement[i][j] = 0;
				}	
			}
				

			sprintf(fileName,"%s%s/B.txt",folder,digits[d]);
			BFile = fopen(fileName,"w");
			for (i = 0; i < N; ++i){
				for (j = 0; j < M; ++j){
					BComplement[i][j] = 0;
				}
			}
			sprintf(fileName,"%s%s/Pi.txt",folder,digits[d]);
			PiFile = fopen(fileName,"w");
			for (i = 0; i < N; ++i){
				PiComplement[i] = 0;			
			}

			k = 0;
			for(; k < R;k++){
				sprintf(AComplementFileName,"%s%s/AComplement%d.txt",folder,digits[d],k);
				AComplementFile = fopen(AComplementFileName,"r");
				sprintf(BComplementFileName,"%s%s/BComplement%d.txt",folder,digits[d],k);
				BComplementFile = fopen(BComplementFileName,"r");
				sprintf(PiComplementFileName,"%s%s/PiComplement%d.txt",folder,digits[d],k);
				PiComplementFile = fopen(PiComplementFileName,"r");

				for(i= 0;i<N;i++){
					for (j = 0; j < N; ++j){
						fscanf(AComplementFile,"%lf",&value);
						AComplement[i][j] += value;
					}
				}
				
				fclose(AComplementFile);
				i = 0;
				for(;i < N;i=i+1){
					j = 0;
					for (; j < M;j=j+1){
						fscanf(BComplementFile,"%lf",&value);
						BComplement[i][j] += value;
					}
				}
				fclose(BComplementFile);
				i = 0;
				for(;i<N;i=i+1){
					fscanf(PiComplementFile,"%lf",&value);
					PiComplement[i] += value;
				}
				fclose(PiComplementFile);
			}

			for(i = 0; i < N; ++i){
				j=0;
				for(;j<N;){
					AComplement[i][j] /= R;
					j=j+1;
				}
			}
			i = 0;
			for(;i<N;i=i+1){
				for (j = 0; j < M;j=j+1){
					BComplement[i][j] /= R;
				}
			}
			i = 0; 
			for(;i < N;){
				PiComplement[i] /= R;			
			     i=i+1;
			}
			ensureStochastic();
			for(i=0; i < N; i++){
				j = 0;
				for (; j < N;j=j+1){
					fprintf(AFile,"%g ",AComplement[i][j]);				
				}
				fprintf(AFile,"\n");
			}
			fclose(AFile);
			for (i = 0; i < N; i=i+1){
				j = 0;
				for (; j< M; j=j+1){
					fprintf(BFile,"%g ",BComplement[i][j]);				
				}
				fprintf(BFile,"\n");
			}
			fclose(BFile);
			i = 0;
			for (; i < N; i=i+1){
				fprintf(PiFile,"%g ",PiComplement[i]);			
			}
			fprintf(PiFile,"\n");
			fclose(PiFile);
			++d;
		}
	}
	printf("\n\nModel building completed\n\n");
}


//model after adding new words
void trainNewModel(){
	bool isUpdated = true;
	int i=0;
	int j = 0;
	int k = 0;
	int r = 0, c = 0, d = 0;
	int f = 0, t = 0, m = 0;
	int modelCount = 0;
	long double ** refA = NULL;
	long double ** refB = NULL; 
	FILE * file = NULL;	
	char temp[100];
	long double * refPi = NULL;
	int range = 0, progressCount = 0;
	long double value = 0;
	int percentageSize = 50, modelLoop = 2, updationLimit = 0;

	//Read the updated information from info.txt
	file = fopen("data/F.txt","r");
	fscanf(file,"%d",&R);
	fclose(file);
	char * folder = "HMM/";
	file = fopen("data/D.txt","r");
	fscanf(file,"%d",&D);
	
	char ** digits = new char * [D];
	for (d = 0; d < D; d=d+1){
		digits[d] = (char *)malloc(sizeof(char *));	
	}
	for (d=0;d<D;d=d+1){
		fscanf(file,"%s",digits[d]);	
	}
	char ** files = NULL;
	char ** dataFiles = NULL;
	fclose(file);

	duration=3;
	N=5;
	M=32;

	file = fopen("data/range.txt","r");
	fscanf(file,"%d",&range);
	fclose(file);

	//Building the universe and the codebook
	dataFiles = new char * [R];
	r = 0;
	for(;r<R;r=r+1){
		dataFiles[r] = (char *)malloc(sizeof(char *));	
	}
	r = 0;
	for(; r<R;r=r+1){
		sprintf(dataFiles[r],"%d",r);	
	}
	files = new char * [4];
	for (r = 0;r<4;r=r+1){
		files[r] = (char *)malloc(sizeof(char *));	
	}
	files[0] = "A";
	files[1] = "B";
	files[2] = "O";
	files[3] = "Pi";
	resetModel(folder, digits, dataFiles, D, R);
	buildUniverse(folder, digits, dataFiles, D, R, range);
	buildCodebook();
	

	//define everything
	define();

	refA = new long double *[N]; //A Matrix
	for(i=0;i<N;i=i+1){
		refA[i] = new long double[N];	
	}
	refB = new long double *[N]; //B Matrix
	for (i=0;i<N;i=i+1){
		refB[i] = new long double[M];	
	}
	char skipLine[1024];	
	char * buffer = new char[1024];
	char fileName[100];
	refPi = new long double[N]; //Pi Array
	char AComplementFileName[100];
	char BComplementFileName[100];
	char PiComplementFileName[100];

	//Build the initial HMM

	printf("\nBuilding the model\n\n");
	for(;modelCount != modelLoop;){
		modelCount=modelCount+1;

		//converge the model for each observation sequence
		d = 0;
		for (;d<D;d=d+1){
			sprintf(fileName,"%s%s/count.txt",folder,digits[d]);
			file = fopen(fileName,"r");
			fscanf(file,"%d",&F);
			generateObservationSequences(folder, digits, dataFiles, d, F, range); //generate the full observation sequence
			//read the model
			fclose(file);
			f = 0;
			for (;f<4;f=f+1){
				sprintf(fileName,"%s%s/%s.txt",folder,digits[d],files[f]);
				file = fopen(fileName,"r"); //open the file and read it
				if(!f){
					i = 0;
					for (;i< N; i=i+1){
						j = 0;
						for (;j<N;j=j+1){
							fscanf(file,"%lf",&A[i][j]);
							refA[i][j] = A[i][j];
						}
					}
				}
				else if(f==1){
					i = 0;
					for (; i < N;i=i+1){
						j = 0;
						for (;j < M;j=j+1){
							fscanf(file,"%lf",&B[i][j]);
							refB[i][j] = B[i][j];
						}
					}
				}
				else if (f == 2){
					fullO = new int *[F];
					i = 0;
					for (; i < F;i=i+1){
						fullO[i] = new int[T];					
					}
					for (i = 0; i < F;i=i+1){
						j = 0;
						for (; j < T;j=j+1){
							fscanf(file,"%d",&fullO[i][j]);						
						}
					}				
				}
				else if (f==3){
					i = 0;
					for (;i<N;i=i+1){
						fscanf(file,"%lf",&Pi[i]);
						refPi[i] = Pi[i];				
					}
				}
				fclose(file);
			}
			k = 0;
			for (; k < F; k++){
				sprintf(AComplementFileName,"%s%s/AComplement%d.txt",folder,digits[d],k);
				AComplementFile = fopen(AComplementFileName,"w+");

				sprintf(BComplementFileName,"%s%s/BComplement%d.txt",folder,digits[d],k);
				BComplementFile = fopen(BComplementFileName,"w+");

				sprintf(PiComplementFileName,"%s%s/PiComplement%d.txt",folder,digits[d],k);
				PiComplementFile = fopen(PiComplementFileName,"w+");

				//reset A
				for (i = 0; i < N; i=i+1){
					for (j = 0; j < N; j=j+1){
						A[i][j] = refA[i][j];			
					}
				}
				
				for (i = 0; i < N; i=i+1){
					for (m = 0; m < M; ++m){
						B[i][m] = refB[i][m];			
					}
				}
				for (j = 0; j < N; j=j+1){
					Pi[j] = refPi[j];				
				}
				//set new O
				O = fullO[k];
				isUpdated = true;
				runViterbi(0);
				updationLimit = 0;

				//run till the model is being updated
				for(;isUpdated && updationLimit++ <= 200;){
					runForwardBackward();
					runBaumWelch();
					runViterbi(1);
					isUpdated = compareAndUpdateModel();
				}
			
				//print the new models to respective files
				i = 0;
				for (;i < N; i=i+1){
					for (j = 0; j < N; j=j+1){
						fprintf(AComplementFile,"%g ",A[i][j]);					
					}
					fprintf(AComplementFile,"\n");
				}
				fclose(AComplementFile);

			
				for (i = 0; i < N; i=i+1){
					for (m = 0; m < M; m=m+1){
						fprintf(BComplementFile,"%g ",B[i][m]);					
					}
					fprintf(BComplementFile,"\n");
				}
				fclose(BComplementFile);

			
				for (j = 0; j < N;j=j+1){
					fprintf(PiComplementFile,"%g ",Pi[j]);				
				}
				fprintf(PiComplementFile,"\n");
				fclose(PiComplementFile);
			}
		}
		//replace the initial model with the new average model
		d = 0;
		for (; d < D; ++d){
			sprintf(fileName,"%s%s/count.txt",folder,digits[d]);

			file = fopen(fileName,"r");
			fscanf(file,"%d",&F);
			sprintf(fileName,"%s%s/A.txt",folder,digits[d]);
			AFile = fopen(fileName,"w");
			sprintf(fileName,"%s%s/B.txt",folder,digits[d]);
			BFile = fopen(fileName,"w");
			sprintf(fileName,"%s%s/Pi.txt",folder,digits[d]);
			PiFile = fopen(fileName,"w");
			fclose(file);

			for (i = 0; i < N; i=i+1){
				j = 0;
				for (; j < N; j=j+1){
					AComplement[i][j] = 0;
				}
			}
			
			for (i = 0; i < N; ++i){
				for (j = 0; j < M; j=j+1){
					BComplement[i][j] = 0;
				}
			}
			i = 0;
			for (;i<N; i=i+1){
				PiComplement[i]=0;			
			}
			k = 0;
			for (; k < F; k=k+1){
				sprintf(AComplementFileName,"%s%s/AComplement%d.txt",folder,digits[d],k);
				AComplementFile = fopen(AComplementFileName,"r");
				sprintf(BComplementFileName,"%s%s/BComplement%d.txt",folder,digits[d],k);
				BComplementFile = fopen(BComplementFileName,"r");
				sprintf(PiComplementFileName,"%s%s/PiComplement%d.txt",folder,digits[d],k);
				PiComplementFile = fopen(PiComplementFileName,"r");

				i = 0;
				for (; i < N;i=i+1){
					j = 0;
					for (; j < N; j=j+1){
						fscanf(AComplementFile,"%lf",&value);
						AComplement[i][j] += value;
					}
				}

				for(i=0; i < N; i=i+1){
					for(j = 0; j < M; j=j+1){
						fscanf(BComplementFile,"%lf",&value);
						BComplement[i][j] += value;
					}
				}

				for(i=0; i < N;i=i+1){
					fscanf(PiComplementFile,"%lf",&value);
					PiComplement[i] += value;
				}
				fclose(BComplementFile);
				fclose(AComplementFile);
				fclose(PiComplementFile);
			}

			for (i = 0; i < N; i=i+1){
				j = 0;
				for (; j < N;j=j+1){
					AComplement[i][j] /= F;
				}
			}
			
			for (i = 0; i < N;i=i+1){
				j = 0;
				for (; j < M;j=j+1){
					BComplement[i][j] /= F;
				}
			}
			
			i = 0;
			for (; i < N; i=i+1){
				PiComplement[i] /= F;			
			}

			ensureStochastic();
			i = 0;
			for (; i < N;i=i+1){
				for (j = 0; j < N; j=j+1){
					fprintf(AFile,"%g ",AComplement[i][j]);				
				}
				fprintf(AFile,"\n");
			}

			for (i=0; i < N; i=i+1){
				for (j = 0; j < M; j=j+1){
					fprintf(BFile,"%g ",BComplement[i][j]);		
				}
				fprintf(BFile,"\n");
			}

			i = 0;
			for (; i < N;i=i+1){
				fprintf(PiFile,"%g ",PiComplement[i]);			
			}
			fprintf(PiFile,"\n");

			fclose(AFile);
			fclose(BFile);
			fclose(PiFile);
		}
	}
}