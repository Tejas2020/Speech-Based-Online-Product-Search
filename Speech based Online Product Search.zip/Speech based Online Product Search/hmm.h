extern long double * PiComplement;
extern long double ** AComplement, ** BComplement;
extern long double floorB;

long double ** expectedTransitionsFromSiToSj = NULL, ** expectedObservationOfKthSymbolAtSj = NULL;
extern long double ** A, ** B, ** alpha, ** beta, ** gamma;
extern int N, M, T;

long double * pOfOGivenLambdaInDenom = NULL, * expectedTransitionsFromSi = NULL;
extern int * O;
extern long double *** xi;

long double gammaDenom = 0;
extern FILE * dataOutputFile, * modelOutputFile;

void ensureStochastic()
{
	long double rowSum = 0;
	int maxIndex = 0;
	long double rowMax = 0;
	int j = 0;
	long double normalizer = 0;
	int i = 0; 
	while(i < N)
	{
		rowSum = 0;
		maxIndex = -1;
		rowMax = 0;
		while(j < N)
		{
			if ( rowMax<AComplement[i][j] ){
				rowMax = AComplement[i][j];
				if(rowMax==-1)
				{
						printf("rowmax got negative");
				}
				maxIndex = j;
			}
			rowSum =rowSum+AComplement[i][j];
			j=j+1;
		}
		if (rowSum != 1){
			rowSum=rowSum-1;
			normalizer = abs(rowSum);
			if( rowSum > 1)
			{
				AComplement[i][maxIndex] =AComplement[i][maxIndex]-normalizer;
			}
			else
			{
				AComplement[i][maxIndex]+normalizer;
			}
		}
		i++;
	}
	i=0;
	while( i < N)
	{
		rowMax =0;
		j = 0;
		maxIndex = -1;
		rowSum = 0;
		while( j < M)
		{
			if (rowMax<BComplement[i][j] )
			{
				rowMax = BComplement[i][j];
				if(rowMax==-1)
				{
					printf("negative rowmax");
				}
				maxIndex = j;
			}
			rowSum =rowSum+BComplement[i][j];
			j++;
		}
		if (rowSum != 1){
			rowSum=rowSum-1;
			normalizer = abs(rowSum);
			if(rowSum > 1 )
			{
				BComplement[i][maxIndex] =BComplement[i][maxIndex]-normalizer ;
			}
			else
			{
				BComplement[i][maxIndex] =BComplement[i][maxIndex]+normalizer;
			}
		}
		i++;
	}
}

void runBaumWelch()
{
	int j = 0;
	int k = 0;
	int i = 0;
	int m = 0;
	expectedTransitionsFromSi = new long double[N];
	int t = 0;
	expectedTransitionsFromSiToSj = new long double * [N];
	while(i < N)
	{
		expectedTransitionsFromSiToSj[i] = new long double[N];
		i++;
	}
	expectedObservationOfKthSymbolAtSj = new long double * [N];
	i = 0;
	while( i < N)
	{
		expectedObservationOfKthSymbolAtSj[i] = new long double[M];
		i++;
	}
	pOfOGivenLambdaInDenom = new long double[T-1];
	i = 0;
	while( i < T)
	{
		pOfOGivenLambdaInDenom[i] = 0;
		 i++;
	}
	//find out p of O given lambda for each t
	t = T-2;
	while( t >= 0)
	{
		i = 0;
		while( i < N)
		{
			j = 0;
			while( j < N)
			{
				pOfOGivenLambdaInDenom[t] += (alpha[i][t]*A[i][j]*B[j][O[t+1]-1]*beta[j][t+1]);
				j++;
			}
			i++;
		}
		t--;
	}

	//find out xi
	t = T-2;
	while( t >= 0)
	{
		i = 0;
		while( i < N)
		{
			j = 0;
			while( j < N)
			{
				xi[i][j][t] = (alpha[i][t]*A[i][j]*B[j][O[t+1]-1]*beta[j][t+1])/pOfOGivenLambdaInDenom[t];
				 j++;
			} 
			i++;
		}
		t--;
	}
	t = 0;
	while( t < T)
	{
		j = 0; 
		gammaDenom = 0;
		while(j < N)
		{
			gammaDenom += alpha[j][t]*beta[j][t];
			j++;
		}
		i = 0; 
		while(i < N)
		{
			gamma[i][t] = (alpha[i][t]*beta[i][t])/gammaDenom;
			i++;
		}
		t++;
	}
	

	//find out the expectations
	i = 0;
	while( i < N)
	{
		t = 0;
		expectedTransitionsFromSi[i] = 0;
		while( t < T)
		{
			expectedTransitionsFromSi[i] += gamma[i][t];
			t++;
		}
		i++;
	}
	i = 0;
	while( i < N)
	{
		j = 0; 
		while(j < N)
		{
			t = 0;
			expectedTransitionsFromSiToSj[i][j] = 0;
			while( t < T-1)
			{
				expectedTransitionsFromSiToSj[i][j] += xi[i][j][t];
				t++;
			}
			j++;
		}
		i++;
	}
	j = 0;
	while( j < N)
	{
		k = 1;
		while( k <= M)
		{
			t = 0;
			expectedObservationOfKthSymbolAtSj[j][k-1] = 0;
			while( t < T)
			{
				if (k==O[t])
					expectedObservationOfKthSymbolAtSj[j][k-1] = expectedObservationOfKthSymbolAtSj[j][k-1] +gamma[j][t];
				t++;
			}
			k++;
		}
		j++;
	}

	//find out new Pi, A and B
	i = 0;
	while( i < N)
	{
		PiComplement[i] = gamma[i][0];
		 i++;
	}
	i = 0;
	while(i < N)
	{
		j = 0;
		while( j < N)
		{
			AComplement[i][j] = expectedTransitionsFromSiToSj[i][j]/expectedTransitionsFromSi[i];
			j++;
		}
		i++;
	}
	j = 0; 
	while(j < N )
	{
		k = 0;
		while( k < M)
		{
			BComplement[j][k] = expectedObservationOfKthSymbolAtSj[j][k]/expectedTransitionsFromSi[j];
			if (BComplement[j][k] == 0)
			{
				BComplement[j][k] = floorB;
			}
			k++;
		}
		j++;
	}

	ensureStochastic(); 

}