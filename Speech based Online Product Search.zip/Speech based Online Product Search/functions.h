extern FILE * AComplementFile;
extern FILE * BComplementFile;
extern FILE * PiComplementFile;
extern long double pStar;
extern long double pStarComplement;
extern long double pOfOGivenLambda;
extern long double ** AComplement;
extern long double ** BComplement;
extern long double ** A;
extern long double ** B;
extern long double ** codebook;
extern long double * PiComplement;
extern long double * Pi;
extern int * O;
extern int N;
extern int M;
extern int T;
extern int duration;
extern int p;
extern int universeSize;
extern char * resultWord;

int samplingRate = 16000;
int noOfFrames = 100;

double * getRValues(double * x, int sampleSize, int p)
{
	double * R;
	R = new double[13];

	int j = 0;
	int i = 0;

	for ( i = 0 ; p >= i ; i += 1)
	{
		R[i]  =  0;
		for( j  =  0 ;  j  <  sampleSize - i ; j += 1 )
		{
			R[i] =  ( x[i+j] * x[j] ) + R[i];
		}
	}
	return R;
}

double * getAValues(double * R, int sampleSize, int p)
{
	//following Durbin's Algorithm
	int i = 0;
	int j = 0;
	double * AA;
	double * E;
	double * K;

	AA = new double[p];
	E = new double[p+1];
	K = new double[p+1];

	double ** tempA = new double*[p+1];

	//initializing everything to 0
	for (i = 0; 1 + p > i; i += 1){
		tempA[i] = new double[1+p];
	}
	for(i = 0; i < p+1; ++i){
		E[i] = 0;
		K[i] = 0;
	}
	for (i = 0 ; 1 + p > i; i += 1){
		j = 0;
		for (; j < 1 + p ; j += 1){
			tempA[i][j] = 0;
		}
	}
		

	//Algorithm steps

	E[0] = R[0];

	for ( i  =  1 ; p >= i ; i += 1 )
	{
		K[i]  = 0;

		for ( j =  1 ;  j  <  i ;  j += 1 ){
			K[i] = ( R[i-j] * tempA[i-1][j] ) + K[i];

		}

		K[i] = -1 * (K[i] - R[i]);

		K[i] = K[i] / E[i-1] ;

		tempA[i][i] = K[i];

		for ( j  =  1; i > j ; j += 1){
			tempA[i][j] = tempA[i-1][j]-(tempA[i-1][i-j] * K[i]);
		}
		E[i] = E[i-1]*(1-( K[i]) * K[i] );
	}
	for (i  =  1 ; p >= i ; i += 1)
	{
		AA[i-1]  =  tempA[p][i];
	}

	return AA;
}

double * getCValues(double * AA, int sampleSize, int p, double r0)
{
	double * C;
	int j = 0;
	int i = 0;

	C = new double[1+p];
	C[0] = log(r0 * r0);

	for ( i  =  1 ; 1 + p > i; i += 1 )
	{
		C[i] = 0;

		double m;
		m = i;

		for (j = 1 ; i > j ; j+=1)
		{
			double k;
			k = j;
			C[i] = AA[i-j-1]*(k/m)*C[j] + C[i];
		}

		C[i] = AA[i-1] + C[i];
	}
	return C;
}

void buildUniverse(char * folder, char * digits[], char * files[], int D, int R, int range)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int d = 0;
	int f = 0;
	int r = 0;
	
	int q = p;

	int index = 0;
	int prog = 0;

	int xCount = samplingRate * duration;
	int shift = 0;
	int temp = 0;
	int dcCount = 0;
	
	int sampleSize;
	sampleSize = xCount/noOfFrames;

	char * buffer;
	buffer = new char[1024];

	double * x = new double[xCount];
	double * RR = NULL;
	double * AA = NULL;
	double * C = NULL;

	double * trainingData = new double[sampleSize];

	double DCShift = 0;
	double maxData = 0;
	double minData = 0;
	double normalizationFactor = 0;
	double copy = 0;

	char fileName[100];

	FILE * universeFile = fopen("data/universe.txt","w+"), * file = NULL;

	/////////////////////////////////////////////////////////////////
	//Implementing a progress bar
	int percentageBreak;
	int nop;
	int progressCount;

	nop = noOfFrames * D * R ;
	percentageBreak = R * D;
	progressCount = 0;
	/////////////////////////////////////////////////////////////////
	printf("\n");
	for ( d =  0 ; D > d ; d += 1)
	{		
		for (f = 0 ; R > f; f += 1)
		{
			sprintf(fileName,"%s%s/%s.txt",folder,digits[d],files[f]);

			file = fopen(fileName,"r");

			dcCount = 0;

			for (i   =  0 ;  1000 > i ; i += 1 ) //for all x values
			{
				fgets(buffer, 1024, file); //read one line from the file

				x[i] = atof(buffer); //convert it into float

				DCShift = x[i] + DCShift;
				dcCount += 1; //add it to dc shift
			}
			DCShift = DCShift / dcCount; //find out dcshift
			for ( i  =  0 ;  1000 > i; i += 1)
			{
				x[i] =x[i] - DCShift; //subtract dcshift from already stored values
				if ( maxData < x[i] ){
					maxData = x[i]; //update maxData
				} 
				if ( minData > x[i]) {
					minData = x[i]; //update minData
				}
			}
			for ( i  =  1000 ; xCount > i ; i += 1) //for rest values
			{
				fgets(buffer, 1024, file); //read one line from the file

				x[i] = atof(buffer); //convert it into float

				x[i] = x[i] - DCShift; //subtract dcshift

				if (x[i] > maxData){
					maxData = x[i]; //update maxData
				} 
				if ( minData > x[i]){
					 minData = x[i]; //update minData
				}
			}
			fclose(file);

			//find out normalization factor
			minData = abs(minData); //get the absolute value of the minimum
			normalizationFactor =  range/  ( ( maxData + minData ) / 2 ) ; //get the normalization factor
			//truncate the normalizationFactor to one decimal digit
			copy = normalizationFactor; //store the normalizationFactor in copy
			while ( 1 > copy) //till copy is less than 1
			{
				shift += 1; //increment shift
				copy = copy * 10; //keep multiplying copy with 10
			}
			temp = (int)copy; //store the integer part of copy in temp
			copy = copy - temp; //subtract temp from copy

			while (shift-- > 0){
				copy = copy / 10;
			} //reverse the shift process
				
			/*the above process helps in getting all the digits except the first decimal digit*/
			normalizationFactor = normalizationFactor - copy; //subtract copy from normalizationFactor
			/*this will ensure that only one digit remains after decimal point*/

			//multiply normalization factor
			for ( i  = 0  ;  xCount > i; i += 1){
				x[i] =  normalizationFactor * x[i] ;

			}

			index = 0;

			for ( r   =  0 ;  noOfFrames  >  r ; r += 1) //indicates frame number
			{
				for ( i  =  0 ; sampleSize > i;  i += 1){
					trainingData[i] = x[index];
					index += 1;
				}


				RR = getRValues(trainingData,sampleSize,p);

				AA = getAValues(RR,sampleSize,p);

				C = getCValues(AA,sampleSize,p,RR[0]);
				

				//raised sine window on C and adding it to the universe file
				for ( j  =   1 ;  p  >=  j ; j += 1 )
				{

					C[j] = ( 1 + ( ( q / 2 ) * sin( ( 3.14 * j ) / q ) ) )  * C[j];

					fprintf(universeFile,"%f ",C[j]);

				}
				universeSize += 1;

				fprintf(universeFile,"\n");
				
				//printing the progress bar
				progressCount += 1;

				if ( progressCount % percentageBreak == 0)
				{
					printf("\r"); //move to the beginning of the line
					/*print the progress*/

					prog = 0;

					printf("[");

					for (prog = percentageBreak; prog <= progressCount; prog += percentageBreak)
					{
						printf("|");
					}
					for (; prog <= nop; prog += percentageBreak)
					{
						printf(" ");

					}

					printf("]%d",(progressCount/percentageBreak)); //print the percentage
				}
			}
		}
	}
	
	fclose(universeFile);

	delete(AA);
	delete(C);
	delete(trainingData);
	delete(x);
	delete(buffer);
	delete(RR);	
}

bool compareAndUpdateModel()
{
	int i = 0;
	int j = 0;
	int t = 0;
	int m = 0;


	//if (pStarComplement < 1e-30)
	//if (abs(pStarComplement-pStar) > 1e-2)
	if ( pStar < pStarComplement )
	{
		//update A
		for ( i   =  0 ;   N  >  i ;  i += 1){
			for ( j  =  0 ; N  > j; j += 1){

				A[i][j] = AComplement[i][j];

			}
		}
			
		
		//update B
		for (i = 0; N > i; i += 1){
			for ( m   =   0 ; M > m; m += 1){
				B[i][m] = BComplement[i][m];

			}
		}
			
		
		//update Pi
		for ( j   =   0 ;  N  > j; j += 1 ){
			Pi[j] = PiComplement[j];

		}
	
		//update pStar
		pStar = pStarComplement;
		//printf("%g\n",pStarComplement);

		/*//reinitialize complement matrices
		PiComplement = new long double [N];

		AComplement = new long double * [N];
		for (i = 0; i < N; ++i)
			AComplement[i] = new long double[N];

		BComplement = new long double * [N];
		for (i = 0; i < N; ++i)
			BComplement[i] = new long double[M];
			*/
		return true;

	}
	else
	{
		//printf("PStar updated- %g\n",pStar);
		return false;
	}
}

void generateObservationSequences(char * folder, char * digits[], char * files[], int digitIndex, int F, int range)
{
	int f = 0;
	int r = 0;
	int i = 0;
	int j = 0;
	int k = 0;
	int q = p;
	int index = 0;
	int codeBookIndex = 0;
	int xCount = samplingRate * duration;
	int dcCount = 0;
	int shift = 0;
	int temp = 0;
	int sampleSize = xCount/noOfFrames;
	int minIndex = -1;


	char * buffer = new char[1024];
	double * x = new double[xCount], * RR = NULL, * AA = NULL, * C = NULL, * trainingData = new double[sampleSize];
	double DCShift = 0;
	double maxData = 0;
	double minData = 0;
	double normalizationFactor = 0;
	double copy = 0;

	int ** Ob = new int*[F];

	long double * distances = new long double[M]; //stores the tokhura distances

	long double w[] = {1.0,3.0,7.0,13.0,19.0,22.0,25.0,33.0,42.0,50.0,56.0,61.0}; //given Tokhura weights

	long double min = 1e30;
	long double temp1 = 0;
	long double temp2 = 0;


	char fileName[100];
	FILE * file = NULL;

	for  ( i  =  0 ;  F > i; i += 1)
	{
		Ob[i] = new int[noOfFrames];	

	}
	for ( f   =   0 ; F > f; f += 1)
	{
		sprintf(fileName,"%s%s/%d.txt",folder,digits[digitIndex],f);

		file = fopen(fileName,"r");

		dcCount = 0;

		for ( i  =   0 ; 1000  > i ; i += 1) //for all x values
		{
			fgets(buffer, 1024, file); //read one line from the file

			x[i] = atof(buffer); //convert it into float

			DCShift = x[i] + DCShift;
			dcCount += 1; //add it to dc shift
		}
		DCShift =  DCShift / dcCount; //find out dcshift
		for (  i   =   0 ; 1000  > i; i += 1)
		{
			x[i] = x[i] - DCShift; //subtract dcshift from already stored values

			if (  minData > x[i] ) {
				minData = x[i]; //update minData
			}
			if (maxData < x[i] ) {
				maxData = x[i]; //update maxData
			}
			
		}
		for ( i  =   1000 ; xCount  > i ; i += 1) //for rest values
		{
			fgets(buffer, 1024, file); //read one line from the file

			x[i] = atof(buffer); //convert it into float

			x[i]  =  x[i] - DCShift; //subtract dcshift


			if ( minData > x[i] ) {
				minData = x[i]; //update minData
			}

			if ( maxData < x[i]  ) {
				maxData = x[i]; //update maxData
			}
			
		}

		fclose(file);

		//find out normalization factor
		minData = abs(minData); //get the absolute value of the minimum

		normalizationFactor = range / ( ( minData + maxData ) / 2 ); //get the normalization factor

		//truncate the normalizationFactor to one decimal digit
		copy = normalizationFactor; //store the normalizationFactor in copy

		while (  1 > copy) //till copy is less than 1
		{
			shift += 1; //increment shift
			copy = copy * 10; //keep multiplying copy with 10
		}

		temp = (int)copy; //store the integer part of copy in temp

		copy = copy- temp; //subtract temp from copy

		while (shift-- > 0) //reverse the shift process
		{
			copy = copy / 10;

		}
		/*the above process helps in getting all the digits except the first decimal digit*/
		normalizationFactor = normalizationFactor - copy; //subtract copy from normalizationFactor
		/*this will ensure that only one digit remains after decimal point*/

		//multiply normalization factor
		for ( i  =   0 ; xCount > i ; i += 1)
		{
			x[i] =  normalizationFactor * x[i];

		}

		index = 0;

		for ( r =  0 ; noOfFrames > r; r += 1 ) //indicates frame number
		{
			for ( i  =  0 ;  sampleSize > i; i += 1)
			{
				trainingData[i] = x[index];
				index += 1;
			}


			RR = getRValues(trainingData,sampleSize,p);

			AA = getAValues(RR,sampleSize,p);

			C = getCValues(AA,sampleSize,p,RR[0]);

			
			//raised sine window on C and adding it to the universe file
			for (j = 1; j <= p; ++j)
			{
				C[j] = C[j]  *  ( 1 + ( ( q / 2 ) * sin( ( 3.14 *  j ) / q ) ) );
			}

			//Tokhura Distance from codebook
			file = fopen("data/codebook.txt","r");

			for ( j   =   0 ; M > j; j += 1) //for each vector in the codebook
			{

				distances[j] = 0;

				for ( k  =    0 ; p > k; k += 1) //for each p value
				{

					temp1 = (long double)C[ 1 + k ];

					fscanf(file,"%lf",&temp2);

					distances[j] = distances[j] +  ( temp1 - temp2 ) * ( temp1 -  temp2 ) * w[k]; //find out the distance
				}

			}
			fclose(file);
			//Minimum index

			min = 1e30; //reset the minimum

			for ( j  =  0 ;  M > j ; j += 1)
			{
				if ( distances[j] < min)
				{
					min = distances[j];

					minIndex = j;

				}

			}

			Ob[f][r] = 1 + minIndex ; //+1 is done to maintain the 1-32 range format and not 0-31 since this subtraction is being done at later steps
		}
	}

	sprintf(fileName,"%s%s/O.txt",folder,digits[digitIndex]);

	file = fopen(fileName,"w+");

	for ( i  =   0 ;  F > i ; i += 1)
	{
		for ( j   =   0 ;  noOfFrames  >  j ; j += 1 )
		{

			fprintf(file,"%d ",Ob[i][j]);

		}
		fprintf(file,"\n");

	}
	fclose(file);
	delete(RR);
	delete(AA);
	delete(C);
	delete(trainingData);
	delete(x);
	delete(buffer);
	delete(Ob);
	
}


void resetCount(char * folder, char * digits[], char * files[], int D, int R)
{
	int d;
	char fileName[100];

	d = 0;

	FILE * countFile;
	countFile = NULL;

	d  =  0 ;
	while (  D > d)
	{
		sprintf(fileName,"%s%s/count.txt",folder,digits[d]);

		countFile = fopen(fileName,"w");

		fprintf(countFile,"%d\n",R);

		fclose(countFile);
		d += 1;
	}

}

void resetModel(char * folder, char * digits[], char * files[], int D, int R)
{
	int d = 0;
	int k = 0;
	int i = 0;
	int j = 0;
	FILE * AFile = NULL, * BFile = NULL, * PiFile = NULL;
	char fileName[100];
	long double * row = new long double[N];

	long double tempB = 0.03125;
	long double one = 1;
	long double zero = 0;

	row[0] = 0.8;
	row[1] = 0.2;
	row[2] = 0;
	row[3] = 0;
	row[4] = 0;

	for (d = 0 ;  D > d; d += 1)
	{
		sprintf(fileName,"%s%s/A.txt",folder,digits[d]);
		AFile = fopen(fileName,"w");

		sprintf(fileName,"%s%s/B.txt",folder,digits[d]);
		BFile = fopen(fileName,"w");

		sprintf(fileName,"%s%s/Pi.txt",folder,digits[d]);
		PiFile = fopen(fileName,"w");

		tempB = 0.03125, one = 1, zero = 0;
		row[0] = 0.8;
		row[1] = 0.2;

		row[2] = 0;
		row[3] = 0;
		row[4] = 0;

		i = 0;
		while ( i < N-1)
		{
			j = 0;
			while( j < N){
				fprintf(AFile,"%g ",row[j]);
				j++;
			}
			fprintf(AFile,"\n");

			j = N-2;
			while( j >= 0){
				row[ 1 + j ] = row[j];
				j-=1;
			}
			row[0] = 0;

			i += 1;
		}
		i = 0;
		while ( i < N-1)
		{
			fprintf(AFile,"%g ",zero);
			i++;
		}
			
		fprintf(AFile,"%g \n",one);

		i = 0;
		while ( i < N)
		{
			j = 0;
			while ( j < M)
			{
				fprintf(BFile,"%g ",tempB);
				j++;
			}
			fprintf(BFile,"\n");
			i++;
		}

		fprintf(PiFile,"%g ",one);
		i = 1;
		while ( i < N){
			fprintf(PiFile,"%g ",zero);
			++i;
		}

		fprintf(PiFile,"\n");

		fclose(AFile);
		fclose(BFile);
		fclose(PiFile);
	}
}

void recognize(char * folder, char * digits[], char * files[], char * dataFiles[], int D, int R, int range, char * testFileName)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int d = 0;
	int f = 0;
	int r = 0;
	int q = p;
	int index = 0;


	int xCount = duration*samplingRate;

	int shift = 0;
	int temp = 0;
	int dcCount = 0;
	

	int sampleSize = xCount/noOfFrames;
	int minIndex = -1;


	char * buffer = new char[1024];
	double * x = new double[xCount], * RR = NULL, * AA = NULL, * C = NULL, * trainingData = new double[sampleSize];


	double maxData = 0;
	double minData = 0;
	double normalizationFactor = 0;
	double copy = 0;
	double DCShift = 0;

	


	int * Ob = new int[noOfFrames];

	long double * distances = new long double[M]; //stores the tokhura distances

	long double w[] = {1.0,3.0,7.0,13.0,19.0,22.0,25.0,33.0,42.0,50.0,56.0,61.0}; //given Tokhura weights

	long double min = 1e30;
	long double temp2 = 0;
	long double maxProb = 0;
	long double temp1 = 0;
	

	char fileName[200], * resultantWord = NULL;

	FILE * file = NULL;
	FILE * AFile = NULL;
	FILE * BFile = NULL;
	FILE * PiFile = NULL;	

	printf("%s\n",testFileName);
	file = fopen(testFileName,"r");

	dcCount = 0;

	i = 0;
	while ( 1000 > i) //for all x values
	{
		fgets(buffer, 1024, file); //read one line from the file
		x[i] = atof(buffer); //convert it into float

		DCShift = x[i] + DCShift;
		dcCount += 1; //add it to dc shift
		i+=1;
	}
	DCShift = DCShift / dcCount; //find out dcshift

	i = 0; 
	while ( 1000 > i)
	{
		x[i] = x[i] - DCShift; //subtract dcshift from already stored values
		if (x[i] > maxData){
			maxData = x[i]; //update maxData
		} 
		if (  minData > x[i]) {
			minData = x[i]; //update minData
		}

		i+=1;
	}
	i = 1000;
	while ( i < xCount) //for rest values
	{
		fgets(buffer, 1024, file); //read one line from the file

		x[i] = atof(buffer); //convert it into float

		x[i] = x[i] - DCShift; //subtract dcshift

		if (x[i] > maxData) {
			maxData = x[i]; //update maxData
		}
		if (x[i] < minData) {
			minData = x[i]; //update minData
		}

		i++;
	}
	fclose(file);

	//find out normalization factor
	minData = abs(minData); //get the absolute value of the minimum

	normalizationFactor  =  range / ( (   minData + maxData ) / 2 ); //get the normalization factor

	//truncate the normalizationFactor to one decimal digit
	copy = normalizationFactor; //store the normalizationFactor in copy

	while ( 1 > copy ) //till copy is less than 1
	{
		shift++; //increment shift
		copy =copy * 10; //keep multiplying copy with 10
	}

	temp = (int)copy; //store the integer part of copy in temp

	copy = copy - temp; //subtract temp from copy
	while (shift-- > 0){
		copy = copy / 10;
	} //reverse the shift process
		
	/*the above process helps in getting all the digits except the first decimal digit*/
	normalizationFactor = normalizationFactor - copy; //subtract copy from normalizationFactor
	/*this will ensure that only one digit remains after decimal point*/

	//multiply normalization factor
	i = 0; 
	while ( xCount > i){
		x[i] =  normalizationFactor * x[i];
		i++;
	}
	
	index = 0;
	
	r = 0;
	while ( noOfFrames > r) //indicates frame number
	{
		i = 0;
		while ( sampleSize > i) //copy the next frame to training data
		{
			trainingData[i] = x[index];
			index += 1;
			i += 1 ;
		}


		//find out Ci
		RR = getRValues(trainingData,sampleSize,p);
		AA = getAValues(RR,sampleSize,p);
		C = getCValues(AA,sampleSize,p,RR[0]);
			
		//raised sine window on C and adding it to the universe file
		j = 1;
		while ( p >= j ) {
			C[j] = ( 1 + ( ( q / 2 ) * sin( ( 3.14 * j ) / q ) ) ) * C[j];
			 j += 1 ;
		}


		//Tokhura Distance from codebook
		file = fopen("data/codebook.txt","r");
		j = 0; 
		while ( M > j ) //for each vector in the codebook
		{
			distances[j] = 0;
			k = 0;
			while ( p > k ) //for each p value
			{
				temp1 = (long double)C[ 1 + k];
				fscanf(file,"%lf",&temp2);

				distances[j] = ( (temp1-temp2) * (temp1-temp2) * w[k] ) + distances[j]; //find out the distance
				k += 1;
			}
			j += 1;
		}
		
		fclose(file);
		//Minimum index

		min = 1e30; //reset the minimum

		j = 0;
		while ( M > j)
		{
			if (distances[j] < min)
			{
				min = distances[j];
				minIndex = j;
			}
			j++;
		}

		Ob[r] = 1 + minIndex; //+1 is done to maintain the 1-32 range format and not 0-31 since this subtraction is being done at later steps
		r += 1;
	}

	O = Ob;

	d = 0;
	while ( D > d)
	{
		strcpy( fileName , folder );
		strcat( fileName , digits[ d ] );
		strcat( fileName  , "/A.txt" );

		AFile = fopen(fileName,"r");

		strcpy( fileName , folder );
		strcat( fileName , digits[d]);
		strcat( fileName ,"/B.txt");

		BFile = fopen( fileName ,"r");

		strcpy( fileName , folder );
		strcat( fileName , digits[ d ] );
		strcat( fileName , "/Pi.txt" );

		PiFile = fopen(fileName,"r");

		for ( i  =  0 ;  N > i; i += 1)
		{
			for ( j  =  0 ; N > j; j += 1)
			{
				fscanf(AFile,"%lf",&A[i][j]);
			}
		}
			

		for ( i  =  0 ; N > i ; i += 1)
		{
			for ( j  =  0 ; M > j ; j += 1)
			{
				fscanf(BFile,"%lf",&B[i][j]);
			}
		}
			

		for ( i  =  0 ; N > i; i += 1)
		{
			fscanf(PiFile,"%lf",&Pi[i]);
		}

		runForwardBackward();



		printf("d = %s, %g\n",digits[d],pOfOGivenLambda);

		if ( maxProb < pOfOGivenLambda  )
		{
			maxProb = pOfOGivenLambda;
			resultantWord = digits[d];
		}

		fclose(AFile);
		fclose(BFile);
		fclose(PiFile);

		d += 1;
	}

	delete(x);
	delete(buffer);
	delete(Ob);
	delete(RR);
	delete(AA);
	delete(C);

	delete(trainingData);

	resultWord = resultantWord;
}
//------------------below funtion do train model

void trainModel(char * word, int range, char * trainFileName)
{

	bool isUpdated = true;
	int xCount = duration*samplingRate;
	int temp = 0;
	int q = p;
	int dcCount = 0;
	int shift = 0;
	
	int sampleSize = xCount/noOfFrames;
	int minIndex = -1;
	int updationLimit = 0;
	int currCount = -1;
	int index = 0;
	int codebookIndex = 0;
	

	char * buffer = new char[1024];
	double * x = new double[xCount];
	double * RR = NULL;
	double * AA = NULL;
	double * C = NULL;

	double * trainingData = new double[sampleSize];

	double maxData = 0;
	double minData = 0;
	double DCShift = 0;
	double normalizationFactor = 0;
	double copy = 0;

	O = new int[noOfFrames];
	long double * distances = new long double[M]; //stores the tokhura distances

	long double w[] = {1.0,3.0,7.0,13.0,19.0,22.0,25.0,33.0,42.0,50.0,56.0,61.0}; //given Tokhura weights

	long double min = 1e30;
	long double temp2 = 0;
	long double tempValue = 0;
	long double temp1 = 0;
	

	FILE * file = NULL;
	
	int k = 0;
	int m = 0;
	int i = 0;
	int j = 0;
	int r = 0;
	
	char filePath[128];

	sprintf(filePath,"HMM/%s/",word);

	char fileName[256];

	//define variables
	define();

	//set A B and Pi to Bakis model
	long double * row = new long double[N];

	long double zero = 0;
	long double tempB = 0.03125;
	long double one = 1;

	row[2] = 0;
	row[3] = 0;
	row[4] = 0;
	row[0] = 0.8;
	row[1] = 0.2;
	

	for ( i  =  0 ; N - 1 > i; i += 1)
	{
		for ( j  =  0 ;  N > j ; j += 1){
			A[i][j] = row[j];
		}

		for (j = N - 2 ;  0  <= j; j -= 1){
			row[j+1] = row[j];
		}

		row[0] = 0;
	}

	for( i = 0  ;  i  <  N - 1 ; i += 1){
		A[N-1][i] = zero;
	}

	A[N-1][N-1] = one;

	for( i   =   0 ; N  > i ; i += 1)
	{
		for ( j   =  0 ; M > j; j += 1 ){
			B[i][j] = tempB;
		}
	}

	Pi[0] = 1;

	for ( i  =   1 ; N > i;  i += 1){
		Pi[i] = 0;
	}

	//generate observation sequence for the spoken word
	file = fopen(trainFileName,"r");

	dcCount = 0;

	for( i  =   0; 1000 > i; i += 1) //for all x values
	{
		fgets(buffer, 1024, file); //read one line from the file

		x[i] = atof(buffer); //convert it into float
		DCShift =  x[i]  +  DCShift;
		dcCount += 1; //add it to dc shift
	}

	DCShift = DCShift / dcCount; //find out dcshift

	for ( i  =   0 ; 1000  > i ; i += 1)
	{
		x[i] = x[i] - DCShift; //subtract dcshift from already stored values
		if ( minData > x[i]) {
			minData = x[i]; //update minData
		}
		if ( maxData < x[i]  ) {
			maxData = x[i]; //update maxData
		}
		
	}
	for( i  =  1000 ;  xCount  >  i ; i += 1 ) //for rest values
	{
		fgets(buffer, 1024, file); //read one line from the file
		x[i] = atof(buffer); //convert it into float

		x[i] = x[i] - DCShift; //subtract dcshift

		if ( minData > x[ i ] ) {
			minData = x[ i ]; //update minData
		}

		if ( maxData < x[ i ] ) {
			maxData = x[ i ]; //update maxData
		}
		
	}
	fclose(file);

	//find out normalization factor
	minData = abs(minData); //get the absolute value of the minimum
	normalizationFactor  =  range / ( ( minData + maxData ) / 2 ); //get the normalization factor

	//truncate the normalizationFactor to one decimal digit
	copy = normalizationFactor; //store the normalizationFactor in copy

	while (  1 > copy ) //till copy is less than 1
	{
		shift += 1; //increment shift
		copy = copy * 10; //keep multiplying copy with 10
	}

	temp = (int)copy; //store the integer part of copy in temp

	copy = copy - temp; //subtract temp from copy

	while (shift-- > 0){
		copy = copy / 10;
	} //reverse the shift process

	/*the above process helps in getting all the digits except the first decimal digit*/
	normalizationFactor = normalizationFactor - copy; //subtract copy from normalizationFactor

	/*this will ensure that only one digit remains after decimal point*/

	//multiply normalization factor
	for ( i   =   0 ;  xCount  > i  ; i += 1 ){
		x[i] = normalizationFactor * x[i];
	}

	index = 0;

	for ( r   =   0 ; noOfFrames > r; r += 1) //indicates frame number
	{
		for ( i  =  0  ; sampleSize > i ; i += 1){
			trainingData[i] = x[index];
			index += 1;
		}

		RR =  getRValues( trainingData , sampleSize, p );
		AA =  getAValues(  RR , sampleSize , p );
		C =   getCValues( AA , sampleSize , p , RR[0] );
			
		//raised sine window on C and adding it to the universe file
		for( j  =  1 ; p >= j; j += 1){
			C[j] = (1+((q/2)*sin((3.14*j)/q))) * C[j];
		}


		//Tokhura Distance from codebook
		file = fopen("data/codebook.txt","r");

		for ( j  =   0 ; M > j; j += 1 ) //for each vector in the codebook
		{
			distances[j]  =  0;
			for( k = 0 ; p > k;  k += 1 ) //for each p value
			{
				temp1 = (long double)C[ 1 + k ];

				fscanf(file,"%lf",&temp2);

				distances[j] = (  ( temp1 - temp2 ) * ( temp1 - temp2 ) * w[k] ) + distances[j]; //find out the distance
			}
		}

		fclose(file);

		//Minimum index
		min = 1e30; //reset the minimum

		for( j  =  0 ; M > j ; j += 1 )
		{
			if ( distances[j] < min)
			{
				min  =  distances[j];
				minIndex  =  j;
			}
		}

		O[r] = 1 + minIndex; //+1 is done to maintain the 1-32 range format and not 0-31 since this subtraction is being done at later steps
	}

	//train the model
	isUpdated = true;


	//update new pStar
	runViterbi(0);

	updationLimit = 0;


	//run till the model is being updated
	while( 200 >=  updationLimit++ && isUpdated )
	{

		runForwardBackward();

		runBaumWelch();

		runViterbi(1);

		isUpdated = compareAndUpdateModel();

	}
			
	//print the new models to respective files
	strcpy(fileName,filePath);

	strcat(fileName,"count.txt");

	file = fopen(fileName,"r");

	fscanf(file,"%d",&currCount);

	fclose(file);

	file = fopen(fileName,"w");

	fprintf(file,"%d\n",(1 + currCount));

	fclose(file);

	strcpy(fileName,filePath);
	strcat(fileName,"A.txt");

	file = fopen(fileName,"r");

	for (  i   =    0;  N > i ; i += 1){
		for ( j  =    0 ;  N  > j; j += 1 ){
			fscanf(file,"%lf",&AComplement[i][j]);
		}
	}		

	fclose(file);

	file = fopen(fileName,"w");

	for( i    =   0 ;  N  >  i ;   i += 1 )
	{
		for(  j  =    0   ; N  > j;  j += 1)
		{
			tempValue = ( A[i][j] + (  AComplement[i][j] * currCount  ) ) / ( 1 + currCount  );
			fprintf(file,"%g ",tempValue);
		}
		fprintf(file,"\n");
	}
	fclose(file);
			
	strcpy(fileName,filePath);

	strcat(fileName,"B.txt");
	
	file = fopen(fileName,"r");


	for( i  =   0 ;  N > i ;  i += 1 ) 
	{
		for ( j  = 0 ;  M  > m  ;  j += 1 )
		{
			fscanf(file,"%lf",&BComplement[i][j]);
		}
	}		

	fclose(file);

	file = fopen(fileName,"w");

	for( i  =   0  ; N > i; i += 1)
	{
		for( m  =   0 ;  M > m  ; m += 1) 
		{
			tempValue = ( ( BComplement[ i ][ m ] * currCount) + B[ i ][ m ] )/( 1 + currCount);
			fprintf(file,"%g ",tempValue);
		}
		fprintf(file,"\n");
	}

	fclose(file);
			
	strcpy(fileName,filePath);

	strcat(fileName,"Pi.txt");

	file = fopen(fileName,"r");

	for (i = 0; i < N; ++i){
		fscanf(file,"%lf",&PiComplement[i]);
	}

	fclose(file);


	file = fopen(fileName,"w");


	for ( j  =   0 ;   N > j; j += 1)
	{
		tempValue =  ( Pi[j] + ( PiComplement[j] * currCount) ) / ( 1 + currCount );

		fprintf(file,"%g ",tempValue);
	}

	fprintf(file,"\n");

	fclose(file);

}

void writeGeneralModel(char * filePath, int R)
{
	char fileName[256];

	FILE * file = NULL;

	int i = 0;
	int j = 0;
	int d = 0;
	int k = 0;
	

	long double * row = new long double[N];

	long double one = 1;
	long double zero = 0;
	long double tempB = 0.03125;
	

	row[3] = 0;
	row[4] = 0;
	row[0] = 0.8;
	row[1] = 0.2;
	row[2] = 0;
	

	sprintf(fileName,"%s/A.txt",filePath);

	file = fopen(fileName,"w");

	i = 0;
	while ( i < N-1)
	{
		for (j = 0; j < N; ++j){
			fprintf(file,"%g ",row[j]);

		}
		fprintf(file,"\n");

		j = N-2;
		while ( j >= 0){
			row[j+1] = row[j];
			j--;
		}
		row[0] = 0;
		i++;
	}

	i = 0;
	while ( N-1 > i){
		fprintf(file,"%g ",zero);
		i++;
	}

	fprintf(file,"%g \n",one);

	fclose(file);

	sprintf(fileName,"%s/B.txt",filePath);
	file = fopen(fileName,"w");

	i = 0;
	while ( i < N)
	{
		j = 0;
		while ( M > j){
			fprintf(file,"%g ",tempB);
			j++;
		}
		fprintf(file,"\n");

		i++;
	}

	fclose(file);

	sprintf(fileName,"%s/Pi.txt",filePath);

	file = fopen(fileName,"w");

	fprintf(file,"%g ",one);

	i = 1;
	while( N > i)
	{
		fprintf(file,"%g ",zero);
		i++;
	}


	fprintf(file,"\n");

	fclose(file);

	sprintf( fileName , "%s/count.txt" , filePath );

	file = fopen(fileName,"w");

	fprintf(file,"%d\n",R);

	fclose(file);
}